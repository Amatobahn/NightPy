![alt text](http://iamgregamato.com/content/img/nightpy/np_logo.svg)

A python wrapper for Nightbot API

API documentation : https://api-docs.nightbot.tv/


How to use:
```
'''
Copy NightPy folder to project root or install the wheel file using pip.
'''

from NightPy.nightpy import NightPy


np = NightPy(api_token_here)

np.skip_current_queue_item()
```
